var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate-draft.js
var generate_draft_exports = {};
__export(generate_draft_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_draft_exports);
process.on("SIGTERM", () => {
  console.log("Received SIGTERM signal, exiting");
  process.exit(0);
});
process.on("SIGINT", () => {
  console.log("Received SIGINT signal, exiting");
  process.exit(0);
});
console.log("Function process started. Environment:", process.env.NETLIFY_DEV ? "Development" : "Production");
var handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  console.log("Received request:", event.httpMethod, event.path);
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    console.log("Handling OPTIONS preflight");
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "CORS preflight successful" })
    };
  }
  if (event.httpMethod !== "POST") {
    console.log("Method not allowed:", event.httpMethod);
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const bodyString = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf-8") : event.body;
    let parsedBody;
    try {
      parsedBody = JSON.parse(bodyString);
    } catch (parseError) {
      console.error("JSON parse error:", parseError.message);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Invalid JSON format" })
      };
    }
    const {
      description,
      inventionType = "device",
      techField = "Technology Field",
      keyFeatures = "Key features not specified"
    } = parsedBody;
    if (!description || description.trim().length < 10) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Description must be at least 10 characters"
        })
      };
    }
    const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
    if (!DEEPSEEK_API_KEY) {
      console.error("DeepSeek API key is missing");
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Server configuration error: API key missing"
        })
      };
    }
    console.log("Calling DeepSeek API...");
    const systemPrompt = `As a USPTO patent attorney, generate a patent application draft for a ${inventionType} in ${techField} with these key features: ${keyFeatures}. Include:
1. Claims with proper USPTO numbering
2. Technical diagrams
3. Physics validation`;
    const startTime = Date.now();
    const apiResponse = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: description.substring(0, 1e3) }
        ],
        temperature: 0.3,
        max_tokens: 2e3,
        top_p: 0.9
      }),
      timeout: 2e4
      // 20-second timeout
    });
    const duration = Date.now() - startTime;
    console.log(`API request took ${duration}ms, status: ${apiResponse.status}`);
    if (!apiResponse.ok) {
      const errorText = await apiResponse.text();
      console.error("DeepSeek API error:", apiResponse.status, errorText.substring(0, 200));
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({
          error: `API request failed (${apiResponse.status})`,
          details: errorText.substring(0, 500)
        })
      };
    }
    const data = await apiResponse.json();
    const draft = data.choices[0]?.message?.content || "";
    console.log("Draft generated successfully. Length:", draft.length);
    const response = {
      statusCode: 200,
      headers,
      body: JSON.stringify({ draft })
    };
    console.log("Scheduling process exit");
    setTimeout(() => {
      console.log("Forcing process exit to prevent timeout");
      process.exit(0);
    }, 100);
    return response;
  } catch (error) {
    console.error("Function error:", error);
    if (error.name === "AbortError") {
      return {
        statusCode: 504,
        headers,
        body: JSON.stringify({
          error: "API request timed out",
          message: "The DeepSeek API did not respond in time"
        })
      };
    }
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
